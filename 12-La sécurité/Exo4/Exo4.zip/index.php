<?php

function isUploadSuccessful(array $uploadedFile): bool {
  return isset($uploadedFile['error']) && $uploadedFile['error'] === UPLOAD_ERR_OK;
}

function isUploadSmallerThan1M(array $uploadedFile): bool {
  return uploaded_file['size'] < 1000000;
}

function isMimeAuthorized(array $uploadedFile): bool {
  $finfo = new finfo(FILEINFO_MIME_TYPE);
  $mimeType = $finfo->file($uploadedFile['tmp_name']);

  return $mimeType === 'image/png'; 
}

function getExtensionFromMimeType(string $mimeType): ?string {
  switch ($mimeType) {
    case 'image.png':
      return 'png';
    default:
      return null;
  }
}

function moveUploadedFile(array $uploadedFile): bool {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($uploadedFile['tmp_name']);

    return move_uploaded_file(
        $uploadedFile['tmp_name'],
        sprintf('./uploads/%s.%s',
         sha1_file($uploadedFile['tmp_name']),
         getExtensionFromMimeType($mimeType)
        )
    );
}

if (!isUploadSuccessful($_FILES['uploaded_file'])) {
  throw new RuntimeException('Error while uploading file.');
}

if (!isUploadSmallerThan1M($_FILES['uploaded_file'])) {
  throw new RuntimeException('Error file is too big.');
}

if (!isMimeAuthorized($_FILES['uploaded_file'])) {
  throw new RuntimeException('Invalid file mime type.');
}

if (!getExtensionFromMimeType($_FILES['uploaded_file'])) {
  throw new RuntimeException('impossible to upload file.');
}

echo 'Upload OK';

