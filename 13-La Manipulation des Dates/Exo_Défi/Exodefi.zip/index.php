<?php

$currentMonth = (int) date('m');
$currentYear = date('Y');
$numDaysinMonth = (int) date('t');
$firstDayofMonth = (int) date('N', mktime(0, 0, 0, $currentMonth, 1, $currentYear));
?>

<table>
  <caption><?php echo date('m/Y') ?></caption>
  <thead><tr><th>L</th><th>M</th><th>M</th><th>J</th><th>V</th><th>S</th><th>D</th></tr></thead>
  <tbody>
    <tr>
      <?php

      if (1 !== $firstDayofMonth ){
        echo '<td colspan ="'. ($firstDayofMonth - 1). '"></td>';
      }

      for ($i = 1; $i <= $numDaysinMonth; $i++) {
        echo '<td>'. $i.'</td>';

        if ((int) date('N', mktime(0, 0, 0, $currentMonth, $i, $currentYear)) === 7) {
          echo '</tr><tr>';
        }
      }

      $daysleft = ($numDaysinMonth + $firstDayofMonth) % 7;
      if (0 !== $daysleft) {
        echo '<td colspan ="' . ((7- $daysleft) + 1). '"></td>';
      }

      ?>
    </tr>
  </tbody>
</table>