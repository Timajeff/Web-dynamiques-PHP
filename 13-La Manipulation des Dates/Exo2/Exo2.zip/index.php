<?php

// 1 

echo mktime(0, 41, 0, 12, 21, 2012). PHP_EOL;

//2

echo mktime(0, 0, 0). PHP_EOL;

//3

echo mktime(-1). PHP_EOL;

$start = microtime(true);

$result = 1;
for ($i = 1; $i <= 10000000; $i++) {
	$result = $i * $result;
}
echo '<br>';
echo 'Script terminé en '.(microtime(true) - $start).' secondes';