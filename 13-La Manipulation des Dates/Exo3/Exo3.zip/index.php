<?php

//1

echo 'le numéro de la semaine en cours est '.date('W'). PHP_EOL;;
echo '<br>';

//2

echo 'la date du jour à minuit en format ISO 6801 est : '.date('c',mktime(0,0,0)). PHP_EOL;;
echo '<br>';

//3

$nextXmas = mktime(0, 0, 0, 12, 25, date('Y') + 1);
echo 'le 25 décembre '.date('Y',$nextXmas).' nous serons un '.date('l', $nextXmas). PHP_EOL;;