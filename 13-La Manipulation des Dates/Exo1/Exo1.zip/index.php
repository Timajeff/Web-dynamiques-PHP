<?php 

$timestamps = [1654863436, 1407673368, 1581337036, 1644495436, 1399724236, 1586521368, 1628598168];

$comparisonTimestamp = 1555188215;

$comparisonfunction = function ($timestamps) use ($comparisonTimestamp) {
  return $timestamps <= $comparisonTimestamp;
};

print_r(array_filter($timestamps, $comparisonfunction)); 