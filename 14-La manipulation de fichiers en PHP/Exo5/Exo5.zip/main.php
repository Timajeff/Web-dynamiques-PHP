<?php

function listFilesAndDirectories(string $path) : void {
  $path = realpath($path).DIRECTORY_SEPARATOR;
  $elements = scandir($path);

  foreach ($elements as $element){
    echo $element;
    echo ' a été crée le '.date('d/m/Y à H:i:s', filectime($path.$element)); 
    echo ' a été modifié le '.date('d/m/Y à H:i:s', filemtime($path.$element));
    echo PHP_EOL;
  }
}

listFilesAndDirectories('.');