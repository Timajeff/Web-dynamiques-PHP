<?php

function openFile(string $file) {
  if (!is_file($file)) {
    return false;
  }
  return fopen($file, 'r');

}


function closefile($resource) {
  if (!is_resource($resource)) {
    return false;
  }
  return fclose($resource);
}

$resource1 = openFile('fichier1.txt');
// Affichera resource(5) of type (stream) par exemple
var_dump($resource1);

$isClosed = closeFile($resource1);
// Affichera bool(true)
var_dump($resource1);

$resource2 = openFile('fichier4.txt');
// Affichera bool(false)
var_dump($resource2);

$isClosed = closeFile($resource2);
// Affichera bool(false)
var_dump($resource2);


