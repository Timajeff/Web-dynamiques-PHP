<?php

function writeUsersInFile(string $file, array $users): bool {
  $resource = fopen($file, 'w');

  if (!$resource) {
    return false;
  }

  foreach ($users as $user) {
    fwrite($resource, implode(' ', $user).PHP_EOL);
  }

  fclose($resource);

  return true;
}

$users = [
    ['Mathilde', 'Dubois'],
    ['Eric', 'Blanchard'],
    ['Manon', 'Dupont'],
];

writeUsersInFile('ecrire-fichier.txt', $users);