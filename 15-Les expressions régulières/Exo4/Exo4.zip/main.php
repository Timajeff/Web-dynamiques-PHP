<?php

$email_addresses =['john@doe.fr', 'john@localhost', 'john+1@localhost', '@doe.fr', 'john@.fr'];

foreach($email_addresses as $email_address) {
  if (preg_match('/[\w+]+@\w+(\.\w*)?/', $email_address)) {
    echo "$email_address est au bon format.". PHP_EOL;
  } else {
    echo "$email_address n'est pas au bon format.". PHP_EOL;
  }
}