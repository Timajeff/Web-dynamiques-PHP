<?php

$emailAdresses = ['john@doe.fr', 'john@localhost', 'john+1@localhost','john+1@localhost+1', '+1@doe.fr', '@doe.fr', 'john@.fr',];

foreach($emailAdresses as $emailAdress) {
  if (preg_match('/\w[\w+]+@\w+(\.\w*)?$/', $emailAdress)){
    echo "$emailAdress est au bon format.". PHP_EOL; 
  } else {
    echo "$emailAdress n'est pas au bon format.". PHP_EOL;
  }
}