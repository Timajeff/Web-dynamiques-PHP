<?php

interface CharacteristicsDisplayable
{
  public function getCharacteristics(): array;
}