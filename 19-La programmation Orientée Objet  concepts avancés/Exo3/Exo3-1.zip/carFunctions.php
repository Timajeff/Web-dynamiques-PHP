<?php

require_once 'Car.php';
require_once 'CharacteristicsDisplayable.php';

function displayCharacteristics(CharacteristicsDisplayable $characteristicsDisplayable): void
{
    echo '<ul>';
    foreach ($characteristicsDisplayable->getCharacteristics() as $name => $value) {
        echo '<li>'.$name.' : '.$value.'</li>';
    }
    echo '</ul>';
}