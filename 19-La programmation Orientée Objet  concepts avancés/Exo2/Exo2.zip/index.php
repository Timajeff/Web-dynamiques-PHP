<?php
// Fichier index.php
require_once 'ElectricCar.php';
require_once  'GasolineCar.php';
$tesla = new ElectricCar(50000, 'Tesla', 560);
$renault = new GasolineCar(20000, 'Renault', 100);
var_dump($tesla->getCharacteristics());
var_dump($renault->getCharacteristics());

displayCharacteristics($tesla);
displayCharacteristics($renault);