<?php


class FooBar 
{


  public const MY_CONST = 0;

  public function Sample_function($sampleVar) 
  {
    switch ($sampleVar) {
      case 1:
        echo 'Cas n°1';
        break;
      case 2:
        echo 'Cas n°2';
        break;
      default:
        echo 'Cas par défaut';
        break;
    }
  }
}

  