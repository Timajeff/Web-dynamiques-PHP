<?php
//1 er étape : déclaration
setcookie('cartUpdate', date('d/m/y h:i:s'), time() + 10800);

//2 eme étape : Affichage.
// Les cookies ne sont accessibles qu'après le rechargement de la page

print_r($_COOKIE['cartUpdate']);

//3 eme étape : Suppression

setcookie('cartUpdate', '', time() - 3600);
?>