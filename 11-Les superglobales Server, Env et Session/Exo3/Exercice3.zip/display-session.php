<?php

session_start();

if (isset($_SESSION['name']) && isset($_SESSION['age']) && isset($_SESSION['favoriteLangages'])) {
  echo sprintf("Je m'appelle %s et j'ai %s ans", $_SESSION['name'], $_SESSION['age'] ) . PHP_EOL;
  echo sprintf("Mes langages de programmation préférés sont les suivants") . PHP_EOL;
  foreach($_SESSION['favoriteLangages'] as $langage) {
    echo $langage . PHP_EOL;
  }
} else {
  echo "Toutes les variables ne sont pas bien définies" . PHP_EOL;
}

$_SESSION = [];
print_r($_SESSION);

session_destroy();