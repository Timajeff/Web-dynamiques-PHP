<?php

session_start();

$_SESSION['name'] = 'John';
$_SESSION['age'] = 37;
$_SESSION['favoriteLangages'] = ['HTML', 'PHP', 'CSS'];

echo 'Session Initialisée';